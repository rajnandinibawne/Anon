"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import ContentGrid from "@/components/content-grid"
import CategoryFilter from "@/components/category-filter"
import { Search } from "lucide-react"

// Mock data for demonstration
const mockData = [
  {
    id: "1",
    title: "How to Build a React App",
    description: "Learn the basics of React in this tutorial",
    thumbnail: "/placeholder.svg?height=200&width=350",
    platform: "youtube",
    category: "education",
    author: "TechTutorials",
    date: "2023-05-15",
  },
  {
    id: "2",
    title: "Morning Coffee Routine",
    description: "My daily coffee ritual",
    thumbnail: "/placeholder.svg?height=200&width=350",
    platform: "instagram",
    category: "lifestyle",
    author: "CoffeeLovers",
    date: "2023-06-22",
  },
  {
    id: "3",
    title: "Stand-up Comedy Highlights",
    description: "Best moments from last night's show",
    thumbnail: "/placeholder.svg?height=200&width=350",
    platform: "facebook",
    category: "comedy",
    author: "ComedyClub",
    date: "2023-07-10",
  },
  {
    id: "4",
    title: "Latest Movie Trailer",
    description: "Check out this upcoming blockbuster",
    thumbnail: "/placeholder.svg?height=200&width=350",
    platform: "youtube",
    category: "entertainment",
    author: "MovieInsider",
    date: "2023-08-05",
  },
  {
    id: "5",
    title: "Web Development Tips",
    description: "Improve your coding skills with these tips",
    thumbnail: "/placeholder.svg?height=200&width=350",
    platform: "facebook",
    category: "education",
    author: "CodeMasters",
    date: "2023-09-18",
  },
  {
    id: "6",
    title: "Travel Photography",
    description: "Beautiful landscapes from my recent trip",
    thumbnail: "/placeholder.svg?height=200&width=350",
    platform: "instagram",
    category: "travel",
    author: "Wanderlust",
    date: "2023-10-30",
  },
]

const categories = [
  { id: "all", name: "All Categories" },
  { id: "comedy", name: "Comedy" },
  { id: "entertainment", name: "Entertainment" },
  { id: "education", name: "Education" },
  { id: "lifestyle", name: "Lifestyle" },
  { id: "travel", name: "Travel" },
]

export default function ContentPlatform() {
  const [activeTab, setActiveTab] = useState("all")
  const [activeCategory, setActiveCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredContent, setFilteredContent] = useState(mockData)

  // Filter content based on active tab, category, and search query
  useEffect(() => {
    let filtered = mockData

    // Filter by platform
    if (activeTab !== "all") {
      filtered = filtered.filter((item) => item.platform === activeTab)
    }

    // Filter by category
    if (activeCategory !== "all") {
      filtered = filtered.filter((item) => item.category === activeCategory)
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.author.toLowerCase().includes(query),
      )
    }

    setFilteredContent(filtered)
  }, [activeTab, activeCategory, searchQuery])

  // Function to fetch data from APIs (simulated)
  const fetchData = async () => {
    // In a real application, you would make API calls here
    console.log("Fetching fresh data...")
    // For now, we're using mock data
  }

  return (
    <div className="space-y-6">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search content..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Platform tabs */}
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="all">All Platforms</TabsTrigger>
          <TabsTrigger value="youtube">YouTube</TabsTrigger>
          <TabsTrigger value="instagram">Instagram</TabsTrigger>
          <TabsTrigger value="facebook">Facebook</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Category filter */}
      <CategoryFilter categories={categories} activeCategory={activeCategory} setActiveCategory={setActiveCategory} />

      {/* Content grid */}
      <ContentGrid content={filteredContent} />

      {/* Refresh button */}
      <div className="flex justify-center mt-8">
        <Button onClick={fetchData}>Refresh Content</Button>
      </div>
    </div>
  )
}

