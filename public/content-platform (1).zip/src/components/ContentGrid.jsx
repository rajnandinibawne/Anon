import { Card, CardContent, CardFooter, CardHeader } from "./ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Facebook, Instagram, Youtube } from "lucide-react"

export default function ContentGrid({ content }) {
  // Function to render platform icon
  const getPlatformIcon = (platform) => {
    switch (platform) {
      case "youtube":
        return <Youtube className="h-4 w-4 text-red-600" />
      case "instagram":
        return <Instagram className="h-4 w-4 text-pink-600" />
      case "facebook":
        return <Facebook className="h-4 w-4 text-blue-600" />
      default:
        return null
    }
  }

  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {content.length > 0 ? (
        content.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <CardHeader className="p-0">
              <div className="relative h-48 w-full">
                <img
                  src={item.thumbnail || "/placeholder.svg"}
                  alt={item.title}
                  className="object-cover w-full h-full"
                />
                <div className="absolute top-2 right-2 bg-background/80 p-1 rounded-md">
                  {getPlatformIcon(item.platform)}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <h3 className="font-semibold text-lg line-clamp-1">{item.title}</h3>
              <p className="text-muted-foreground text-sm mt-1 line-clamp-2">{item.description}</p>
            </CardContent>
            <CardFooter className="p-4 pt-0 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src="https://placehold.co/30x30" />
                  <AvatarFallback>{item.author.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">{item.author}</span>
              </div>
              <span className="text-xs text-muted-foreground">{formatDate(item.date)}</span>
            </CardFooter>
          </Card>
        ))
      ) : (
        <div className="col-span-full text-center py-12">
          <p className="text-muted-foreground">No content found matching your filters.</p>
        </div>
      )}
    </div>
  )
}

