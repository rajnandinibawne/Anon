import ContentPlatform from "./components/ContentPlatform"
import { ThemeProvider } from "./components/theme-provider"

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Content Explorer</h1>
        <ContentPlatform />
      </div>
    </ThemeProvider>
  )
}

export default App

